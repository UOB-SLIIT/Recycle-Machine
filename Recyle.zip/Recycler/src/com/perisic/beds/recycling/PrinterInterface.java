package com.perisic.beds.recycling;
/**
 * This class represent a printer. Note that this is not implemented here. 
 * @author Marc Conrad
 *
 */
public interface PrinterInterface {
	/**
	 * The string that is to be printed.
	 * @param str
	 */
	public void print(String str); 
}

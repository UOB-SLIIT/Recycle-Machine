package com.perisic.beds.recycling;

/**
* Represents a bag to be recycled.
 * @author Salitha
 *
 */
public class Bag extends DepositItem {
	/**
	 * 
	 */
	public Bag() { 
		value = 10; 
		name = "Bag";
	}
}
